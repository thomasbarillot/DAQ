#!/usr/bin/env python3
#
# Copyright 2016 Signal Processing Devices Sweden AB. All rights reserved.
#
# Description:    Helper functions for FWATD example scripts
# Documentation:
#

import ctypes as ct
import os

# This function loads the ADQAPI library using ctypes
def adqapi_load():
    if os.name == 'nt':
        ADQAPI = ct.cdll.LoadLibrary(r'ADQAPI.dll')
    else:
        ADQAPI = ct.cdll.LoadLibrary('libadq.so')
            
    # Manually set return type from some ADQAPI functions
    ADQAPI.CreateADQControlUnit.restype = ct.c_void_p
    ADQAPI.ADQ_GetRevision.restype = ct.c_void_p
    ADQAPI.ADQ_GetPtrStream.restype = ct.POINTER(ct.c_int16)
    ADQAPI.ADQControlUnit_FindDevices.argtypes = [ct.c_void_p]
            
    # Print ADQAPI revision
    print('ADQAPI loaded, revision {:d}.'.format(ADQAPI.ADQAPI_GetRevision()))            
            
    return ADQAPI

# Convenience function when printing status from ADQAPI functions
def adq_status(status):
  if (status==0):
    return 'FAILURE'
  else:
    return 'OK'    

# Print revision info for an ADQ device
def print_adq_device_revisions(ADQAPI, adq_cu, adq_num):
    # Get revision info from ADQ
    rev = ADQAPI.ADQ_GetRevision(adq_cu, adq_num)
    revision = ct.cast(rev,ct.POINTER(ct.c_int))
    print('\nConnected to ADQ #{:d}'.format(adq_num))
    # Print revision information
    print('FPGA Revision: {}'.format(revision[0]))
    if (revision[1]):
        print('Local copy')
    else:
        print('SVN Managed')
        if (revision[2]):
            print('Mixed Revision')
        else :
            print('SVN Updated')
            print('')
            
def print_wfa_status(ADQAPI, adq_cu, adq_num):
  records_accumulated = ct.c_uint()
  records_transferred = ct.c_uint()
  stream_status = ct.c_uint()
  wfa_status = ct.c_uint()
  if (ADQAPI.ADQ_ATDGetWFAStatus(adq_cu, adq_num,
                                 ct.byref(records_accumulated),
                                 ct.byref(records_transferred),
                                 ct.byref(stream_status),
                                 ct.byref(wfa_status))):
    print('ATD WFA status: {:x}'.format(wfa_status.value))
    if (wfa_status.value & 0x1):
      print('\tAccumulator overflow.')
    if (wfa_status.value & 0x2):
      print('\tInput FIFO overflow (fast).')
    if (wfa_status.value & 0x4):
      print('\tDRAM FIFO overflow (fast).')
    if (wfa_status.value & 0x8):
      print('\tInput FIFO overflow (slow).')
    if (wfa_status.value & 0x10):
      print('\tDRAM FIFO overflow (slow).')
    if (wfa_status.value & 0x20):
      print('\tRAM collision.')
    if (wfa_status.value & 0x40):
      print('\tAccumulation segment store FIFO overflow (fast).')
    if (wfa_status.value & 0x80):
      print('\tAccumulation segment fetch FIFO overflow (fast).')
    if (wfa_status.value & 0x100):
      print('\tWFA segment FIFO overflow (fast).')
    if (wfa_status.value & 0x200):
      print('\tRaw segment FIFO overflow (slow).')
    if (wfa_status.value & 0x400):
      print('\tRAM collision during readout.')
    if (wfa_status.value == 0):
      print('\tOK')
    
    print('Stream status: {:x}'.format(stream_status.value))
    if (stream_status.value != 0):
      print('\tDMA FIFO overflow.')
    if (stream_status.value == 0):
      print('\tOK')
  else:
    print('ATD WFA status readout failed.')
