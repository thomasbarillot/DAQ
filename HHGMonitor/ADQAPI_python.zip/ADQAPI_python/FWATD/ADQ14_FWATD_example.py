#!/usr/bin/env python3
#
# Copyright 2016 Signal Processing Devices Sweden AB. All rights reserved.
#
# Description:    ADQ14 FWATD streaming example
# Documentation:
#

import numpy as np
import ctypes as ct
import sys
import time
import matplotlib.pyplot as plt
from example_helpers import print_wfa_status, adqapi_load, print_adq_device_revisions

# WFA settings
record_length            = 9216 # Multiple of 72 required
nof_accumulations        = 64   # Number of accumulations [1, 65536] supported with safe scaling
nof_repeats              = 1    # Number of repeated accumulations
pretrig_samples          = 0    # Samples before trigger
trigger_holdoff          = 0    # Samples to skip after trigger

# Level trig settings
trig_channel       = 1 # 1 = A
                       # 2 = B
                       # 3 = C
                       # 4 = D
trig_resetval      = 100 # Codes
trig_level         = 0 # Codes

# Thresholding settings
threshold = 2000 # Codes, threshold level
baseline = 0 # Codes, replacement level
neg_pulse_enable = 0
thr_bypass = 1
thr_coefficients = (ct.c_uint*9)(*[0x0000,
                                   0x0000,
                                   0x0000,
                                   0x0000,
                                   0x0000,
                                   0x0000,
                                   0x0000,
                                   0x0000,
                                   0x4000])

# Input range, only applicable for units with -VG option
input_range = 2000.0 # mVpp

# Adjustable bias
adjustable_bias = 0 # Codes

# DBS settings
dbs_bypass = 1
dbs_dc_target = 0 # Codes
dbs_lower_saturation_level = 0 # Codes
dbs_upper_saturation_level = 0 # Codes

# Plot data if set to True
plot_data = True

# DMA transfer buffer settings
transfer_buffer_size = 1024*1024*4 # Bytes, size of DMA buffer
num_transfer_buffers = 8 # Number of DMA buffers

# Load ADQAPI
ADQAPI = adqapi_load()
# Create ADQControlUnit
adq_cu = ct.c_void_p(ADQAPI.CreateADQControlUnit())

# Enable error logging from ADQAPI
ADQAPI.ADQControlUnit_EnableErrorTrace(adq_cu, 3, '.')

# Find ADQ devices
ADQAPI.ADQControlUnit_FindDevices(adq_cu)
n_of_ADQ  = ADQAPI.ADQControlUnit_NofADQ(adq_cu)
print('Number of ADQ found:  {}'.format(n_of_ADQ))

# Exit if no devices were found
if n_of_ADQ < 1:
  print('No ADQ connected.')
  ADQAPI.DeleteADQControlUnit(adq_cu)
  sys.exit(1)

# Select ADQ
if n_of_ADQ > 1:
  adq_num = int(input('Select ADQ device 1-{:d}: '.format(n_of_ADQ)))
else:
  adq_num = 1

print_adq_device_revisions(ADQAPI, adq_cu, adq_num)

# Set clock source
ADQ_CLOCK_INT_INTREF = 0
ADQ_CLOCK_EXT = 2
ADQAPI.ADQ_SetClockSource(adq_cu, adq_num, ADQ_CLOCK_INT_INTREF)

# Get number of channels from device
number_of_channels = ADQAPI.ADQ_GetNofChannels(adq_cu, adq_num)

# Setup input range if available
setrange = ct.c_float(2000.0)
if ADQAPI.ADQ_HasAdjustableInputRange(adq_cu, adq_num):
  for ch in range(1,ADQAPI.ADQ_GetNofChannels(adq_cu, adq_num)+1):
    success = ADQAPI.ADQ_SetInputRange(adq_cu, adq_num,
                                       ch,
                                       ct.c_float(input_range),
                                       ct.byref(setrange))
    if (success == 0):
      print('Failed setting input range for channel {}.'.format(['A','B','C','D'][ch-1]))
    else:
      print('Input range for ch {} set to {:.3f} mVpp.'.format(['A','B','C','D'][ch-1],
                                                               setrange.value))

# Setup adjustable bias
if ADQAPI.ADQ_HasAdjustableBias(adq_cu, adq_num):
  for ch in range(1,ADQAPI.ADQ_GetNofChannels(adq_cu, adq_num)+1):
    success = ADQAPI.ADQ_SetAdjustableBias(adq_cu, adq_num, ch, adjustable_bias)
    if (success == 0):
      print('Failed setting adjustable bias for channel {}.'.format(['A','B','C','D'][ch-1]))
    else:
      print('Adjustable bias for ch {} set to {:d} codes.'.format(['A','B','C','D'][ch-1],
                                                                  adjustable_bias))

  print('Waiting for bias settling...')
  time.sleep(2)

# Setup DBS
dbs_nof_inst = ct.c_uint()
ADQAPI.ADQ_GetNofDBSInstances(adq_cu, adq_num, ct.byref(dbs_nof_inst))
for dbs_inst in range(dbs_nof_inst.value):
    success = ADQAPI.ADQ_SetupDBS(adq_cu, adq_num,
                                  dbs_inst,
                                  dbs_bypass,
                                  dbs_dc_target,
                                  dbs_lower_saturation_level,
                                  dbs_upper_saturation_level)
    if (success == 0):
      print('Failed setting up DBS for channel {}.'.format(['A','B','C','D'][ch-1]))

# Setup trigger
SW_TRIG = 1
EXT_TRIG_1 = 2
EXT_TRIG_2 = 7
EXT_TRIG_3 = 8
LVL_TRIG = 3
INT_TRIG = 4
LVL_FALLING = 0
LVL_RISING = 1
trig_type = LVL_TRIG
success = ADQAPI.ADQ_SetTriggerMode(adq_cu, adq_num, trig_type)
if (success == 0):
    print('ADQ_SetTriggerMode failed.')
success = ADQAPI.ADQ_SetLvlTrigLevel(adq_cu, adq_num, trig_level)
if (success == 0):
    print('ADQ_SetLvlTrigLevel failed.')
success = ADQAPI.ADQ_SetTrigLevelResetValue(adq_cu, adq_num, trig_resetval)
if (success == 0):
    print('ADQ_SetTrigLevelResetValue failed.')
success = ADQAPI.ADQ_SetLvlTrigChannel(adq_cu, adq_num, trig_channel)
if (success == 0):
    print('ADQ_SetLvlTrigChannel failed.')
success = ADQAPI.ADQ_SetLvlTrigEdge(adq_cu, adq_num, LVL_RISING)
if (success == 0):
    print('ADQ_SetLvlTrigEdge failed.')

# Setup WFA
success = ADQAPI.ADQ_ATDSetupWFA(adq_cu, adq_num,
                                 record_length,
                                 pretrig_samples,
                                 trigger_holdoff,
                                 nof_accumulations,
                                 nof_repeats)
if (success == 0):
    print('ADQ_ATDSetupWFA failed.')

# Setup thresholding
for ch in range(number_of_channels):
  success = ADQAPI.ADQ_ATDSetupThreshold(adq_cu, adq_num,
                                         ch+1,
                                         threshold,
                                         baseline,
                                         neg_pulse_enable,
                                         thr_bypass)
  if (success == 0):
    print('ADQ_ATDSetupThreshold failed.')
  success = ADQAPI.ADQ_ATDSetThresholdFilter(adq_cu, adq_num,
                                             ch+1,
                                             ct.byref(thr_coefficients))
  if (success == 0):
    print('ADQ_ATDSetThresholdFilter failed.')

# Setup size of transfer buffers
print('Setting up streaming...')
ADQAPI.ADQ_SetTransferBuffers(adq_cu, adq_num, num_transfer_buffers,
                              transfer_buffer_size)

# Create some buffers for the full records
data_32bit = [np.array([], dtype=np.int32),
              np.array([], dtype=np.int32),
              np.array([], dtype=np.int32),
              np.array([], dtype=np.int32)]
target_buffers = (ct.POINTER(ct.c_int32*(record_length*nof_repeats))*4)()
for bufp in target_buffers:
  bufp.contents = (ct.c_int32*(record_length*nof_repeats))()

# Wait for keypress, after this the unit is ready to recieve data
response = input("\nPress enter when ready to collect data.")

# Start WFA transfer
print('Waiting for data...')
channels_mask = 0xf
success = ADQAPI.ADQ_ATDStartWFA(adq_cu, adq_num,
                                 target_buffers, channels_mask, 1)
if success == 0:
  print('ADQ_ATDStartWFA failed!')

# Convert data to Numpy arrays
data_32bit = [np.frombuffer(target_buffers[ch].contents,
                            dtype=np.int32, count=record_length*nof_repeats)
              for ch in range(number_of_channels)]

# Print WFA status
print('\nChecking status after data collection...')
print_wfa_status(ADQAPI, adq_cu, adq_num)

# Plot data
if plot_data:
  for ch in range(0,ADQAPI.ADQ_GetNofChannels(adq_cu, adq_num)):
    print('Plotting data from channel {}.'.format(['A','B','C','D'][ch]))
    fig = plt.figure(ch)
    title = 'Channel {}'.format(['A','B','C','D'][ch])
    plt.plot(np.arange(len(data_32bit[ch])),
             setrange.value*data_32bit[ch]/(2**(16+np.log2(nof_accumulations))),
             '.-')
    fig.canvas.set_window_title(title)
    plt.title(title)
    plt.ylabel('level [mV]')
    plt.xlabel('time [ns]')
    plt.grid(which='both')

  plt.show()

# Delete ADQ device handle
ADQAPI.ADQControlUnit_DeleteADQ(adq_cu, adq_num)
# Delete ADQControlunit
ADQAPI.DeleteADQControlUnit(adq_cu)

print('Done.')
